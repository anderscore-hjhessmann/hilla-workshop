declare module '*.css' {
  import { CSSResultGroup } from 'lit';
  const content: CSSResultGroup;
  export default content;
}
